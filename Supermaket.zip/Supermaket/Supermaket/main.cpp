#include <iostream>
#include <string>
#include <fstream>
#include "Clients/client.h"
#include "Commandes/commande.h"
#include "Articles/article.h"
#include "Livraisons/livraison.h"
#include <list>
#include <stdlib.h>

using namespace std;

// Fonctions qui nous informe sur l'etat du fichier



int main()
{
/*
	Client Math(87, "Mingue", "Mathieu", "01-01-2019", 'M');
	int num=87;
	char g='M';
	string name="Mingue", surname="Mathieu", date="01-01-2019";
	//Math.Client(87, name, surname, date, 'M');
	Commande cmd(88, 87, "En cours" ,"17Q2750", 1 );

	cout << "Le client par defaut est : " << Math.getprenom();
	cmd.show_commande();
	Article art("REFERENCE", "FIRST ART", 100, 1, 0);
	art.show_article();

	Livraison livre(75, 81, 95, "17Q2750");

	livre.show_livraison();

	cout << "\n\n********************LISTER LES DIFFERENTS CLIENT*******************\n\n";

	Client Liste_client[100];
	int n,i;
	cout << "Entrer le nombre de client\n";
	cin >> n;
	cout<<"Entre les informations sur votre client. \n ( numero -> nom -> prenom -> date -> genre) \n";
	for(i=0;i<n;i++)
	{
		int num; string n,p,d; char g;
		cin >> num >> n >> p >> d>>g;
		Liste_client[i].setnumero(num);
		Liste_client[i].setnom(n);
		Liste_client[i].setprenom(p);
		Liste_client[i].setdate(d);
		Liste_client[i].setgenre(g);
	}
	cout << "\n\nLe liste de vos client est : \n";
	for(i=0;i<n;i++)
	{
		Liste_client[i].show_client();
	}


	cout << "\n**************************FIN DU PROGRAMME CLIENT ********************\n\n";

	cout << "\n\n*************************ENREGISTREMENT DES COMMANDES*********************\n\n ";

	Commande Liste_commande[100];
	int nb_cmd,j;
	cout<<"Entrer le nombre de commande : ";
	cin >> nb_cmd;
	cout << "Entrer les informations sur les commandes : (NB: number -> Shop_num -> stat -> refer -> qte)\n";
	for(i=0; i<nb_cmd;i++)
	{
		int num_cmd, sh_num, q;
		string st;
		string ref;
		cin >> num_cmd >> sh_num >> st >> ref >> q;
		Liste_commande[i].set_number(num_cmd);
		Liste_commande[i].set_shop_num(sh_num);
		Liste_commande[i].set_stat(st);
		Liste_commande[i].set_refer(ref);
		Liste_commande[i].set_qte(q);

	}
	for(i=0; i<nb_cmd;i++)
	{
		Liste_commande[i].show_commande();
	}
*/

// Nous allons proceder maintenant a l'enregistrement des client dans un fichier

    /*Client client(205, "Mingue", "Mathieu", "01-01-2019", 'M');
    cout <<"Le client que je souhaite enregistrer dans le fichier est \n";
    client.show_client();
    Enregistrer_client(client);
    int l;
    l = nombre_ligne_fichier_client();
    cout<<"Le nombre de ligne est : "<< l << "\n";
    //contenu_fichier_client = copy_client_file(l);
    Client *contenu_fichier_client = copy_client_file();
    for(int k=0;k<l;k++)
    {
        contenu_fichier_client[k].show_client();
    }

    cout << "\n\n entrer le numero d'un client a chercher dans la liste\n";
    int nume;
    cin >> nume;
    int trouver = recherche_liste_client_numero(nume);

    if (trouver != (-1))
        cout << "\nUn client porte bien ce numero \n";
    else
        cout << "\nAucun client n'est enregistrer a ce numero \n";


    cout << "Entrer le nom d'une personne a recherchee dans la liste \n";
    string mot;
    cin >> mot;
    if(recherche_liste_client_nom(mot)!= (-1))
        cout <<"\nUn client porte bien ce nom\n";
    else
        cout <<"\nAucun client ne porte ce nom\n";

    cout << "\n\n*********FIN D'ESSAIS********\n\n";

    Affiche_Clients();
    cout << "\n\n";

    cout << "Procedons a la supprimer du fichier\n";
    supprime_client(204);


    cout << "*****************************ADMINISTRATION DE LA PARTIE COMMANDE**********************";
    Commande cmd1( 3, 203, "En_cours", "cmd3", 4 );
    Enregistrer_commande(cmd1);
    liste_commande_du_client(203);*/
    menu1();


	return 0;
}
