#include <iostream>
#include "client.h"
#include <string>

Client::Client()
{};
Client::Client(int num, std::string n, std::string p, std::string d, char g)
{
	numero = num;
	nom = n;
	prenom = p;
	date = d;
	genre = g;
}
void Client::setnumero(int q)
{
	numero = q;
}
int Client::getnumero()
{
	return numero;
}
void Client::setnom(std::string n)
{
	nom = n;
}
string Client::getnom()
{
	return nom;
}
void Client::setprenom(std::string p)
{
	prenom = p;
}
string Client::getprenom()
{
	return prenom;
}
void Client::setdate(std::string d)
{
	date = d;
}
string Client::getdate()
{
	return date;
}

void Client::setgenre(char c)
{
	genre = c;
}
char Client::getgenre()
{
	return genre;
}

void Client::show_client()
{
	std::cout << "Le client est representer par : \n Le numero du client est :  " << numero << "\n Son nom est : "<< nom << "\n Son prenom est : " << "\n Sa date de naissance est : " << date << "\n son genre est : " << genre <<"\n"; 
}