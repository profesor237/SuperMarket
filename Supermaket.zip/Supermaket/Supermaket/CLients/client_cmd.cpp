/*
#include <iostream>
#include <string>
#include "client.h"
#include "../Commandes/commande.h"
#include <list>

using namespace std;

void liste_commande_du_client(int num)
{
	int indexe = recherche_liste_commande_num_client(num);
	if (indexe = -1)
	{
		cout << "La commande du client de numero " << num << "est :\n";
		Commande *cmd = copy_commande_file();
		cmd[indexe].show_commande();
	}
	else
		cout << "Aucne commande n'est enregistre pour ce client\n";
}
*/
