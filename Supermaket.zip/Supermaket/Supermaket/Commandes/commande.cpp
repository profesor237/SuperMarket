#include <iostream>
#include <string>
#include "commande.h"

/* definition des methodes */

Commande::Commande()
{
	number = 0;
	shop_num = 0;
	stat = "En cours";
	refer = " ";
	qte = 0;
}

Commande::Commande(int num, int sh_num, std::string st, std::string ref, int q )
{
	number = num;
	shop_num = sh_num;
	stat = st;
	refer = ref;
	qte = q;
}

void Commande::set_number(int cmd)
{
	number = cmd;
}
int Commande::get_number()
{
	return number;
}
void Commande::set_shop_num(int a)
{
	shop_num = a;
}

int Commande::get_shop_num()
{
	return shop_num;
}

void Commande::set_stat(std::string t)
{
	stat = t;
}

string Commande::get_stat()
{
	return stat;
}

void Commande::set_refer(std::string T)
{
	refer = T;
}

string Commande::get_refer()
{
	return refer;
}
void Commande::set_qte(int q)
{
	qte = q;
}

int Commande::get_qte()
{
	return qte;
}

void Commande::show_commande()
{
	std::cout << "La commande est : \n Numero " << number << "\n Numero du Client  " << shop_num << "\n Etat " << stat << "\n quantite  " << qte << "\n";
}
