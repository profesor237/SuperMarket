#if !defined(__COMMANDE__)
#define __COMMANDE__

#include <list>
#include <string>
#include "../Clients/client.h"
#include "../Articles/article.h"
#include "../Livraisons/livraison.h"
#include <stdlib.h>
using namespace std;

class Commande
{
public:
	Commande();
	Commande(int, int , string, string, int);
	void set_number(int);			// defini le numero de la commande
	int get_number();
	void set_shop_num(int);			// defini le numero du client
	int get_shop_num();
	void set_stat(string);			// defini l'etat des commande, "en cours" ou "livre"
	string get_stat();
	void set_refer(string);			// defini les reference de la commande
	string get_refer();
	void set_qte(int);				// defini la quantite de la commande
	int get_qte();
	void show_commande();			// Affiche toutes les informations sur la commande

private:
	int number;
	int shop_num;
	string stat;
	string refer;
	int qte;

};

Commande::Commande()
{
	number = 0;
	shop_num = 0;
	stat = "En cours";
	refer = " ";
	qte = 0;
}

Commande::Commande(int num, int sh_num, string st, string refe, int q )
{
	number = num;
	shop_num = sh_num;
	stat = st;
	refer = refe;
	qte = q;
}

void Commande::set_number(int cmd)
{
	number = cmd;
}
int Commande::get_number()
{
	return number;
}
void Commande::set_shop_num(int a)
{
	shop_num = a;
}

int Commande::get_shop_num()
{
	return shop_num;
}

void Commande::set_stat(string t)
{
	stat = t;
}

string Commande::get_stat()
{
	return stat;
}

void Commande::set_refer(string T)
{
	refer = T;
}

string Commande::get_refer()
{
	return refer;
}
void Commande::set_qte(int q)
{
	qte = q;
}

int Commande::get_qte()
{
	return qte;
}

void Commande::show_commande()
{
	cout << "La commande est : \n Numero " << number << "\n Numero du Client  " << shop_num << "\n Etat " << stat << "\n reference " << refer <<"\n quantite  " << qte << "\n";
}


// Definition des autres fonctions membres


int nombre_ligne_fichier_commande()
{
	int n=0;
	ifstream flux_commande("C:/MesFichiersC++/Supermaket/Commandes/Fichier_Commande.txt", ios::in);
	string ligne;
    while(getline(flux_commande, ligne))
    {
        n++;
    }
    flux_commande.close();
	return n;
}

//--------creation d'une liste chainees

// recherche d'une valeur dans une lise chainee

bool list_find_cmd(list<int> l, int val)
{
	for(list<int>::iterator it = l.begin(); it!=l.end();++it)
	{
		if(*it == val)
			 return 1;
	}
	return 0;
}
// Fonction de copie du contenue d'un fichier dans un tableau
Commande *copy_commande_file()        // represente la taille du tableau
{
    Commande *tab = new Commande[100];
	ifstream flux_commande("C:/MesFichiersC++/Supermaket/Commandes/Fichier_Commande.txt" , ios::in);
	int taille = nombre_ligne_fichier_commande();

    for(int j=0;j<=taille;j++)
    {
        int num, cl_num, qte ; string etat, refe;
        flux_commande >> num >> cl_num >> etat >> refe >> qte;

    // j'imprime toutes la liste dans un tableau de client

        tab[j].set_number(num);
        tab[j].set_shop_num(cl_num);
        tab[j].set_stat(etat);
        tab[j].set_refer(refe);
        tab[j].set_qte(qte);
	}
	flux_commande.close();
	return tab;
}

//----------rechercher un numero d'une commande dans le fichier

int recherche_liste_commande_numero(int val)
{
    Commande *liste_commande = copy_commande_file();      // liste des commandes du fichier
    int n = nombre_ligne_fichier_commande();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_commande[i].get_number()==val)
            return i;
    }
    return -1;
}

int recherche_liste_commande_num_client(int cl_num)             //recherche en fonction du nom du client
{
    Commande *liste_commande = copy_commande_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_commande();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_commande[i].get_shop_num()==cl_num)
        {
            return i;
        }

    }
    return -1;
}

int recherche_liste_commande_etat(string etat)             // recherche en fonction de l'etat de la commande
{
    Commande *liste_commande = copy_commande_file();      // liste des commandes du fichier
    int n = nombre_ligne_fichier_commande();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_commande[i].get_stat()==etat)
            return i;
    }
    return -1;
}

int recherche_liste_commande_reference(string refe)
{
    Commande *liste_commande = copy_commande_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_commande();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_commande[i].get_refer()==refe)
            return i;
    }

    return -1;
}

int recherche_liste_commande_quantite(int qte)
{
    Commande *liste_commande = copy_commande_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_commande();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_commande[i].get_qte()==qte)
            return i;
    }
    return -1;
}

void Enregistrer_commande(Commande commande)
{
	int taille;
	list<int> liste_num_commande;				// stocke less dentifiant de chaque client (numero)
	ifstream flux_commande("C:/MesFichiersC++/Supermaket/Commandes/Fichier_Commande.txt" , ios::in);

	taille = nombre_ligne_fichier_commande();
    Commande tab[taille+1];
    for(int j=0;j<=taille;j++)
    {
        int num, cl_num, qte; string refe, etat;
        flux_commande >> num >> cl_num >> etat >> refe >> qte;

        liste_num_commande.push_back(num);        // je met le numero du client dans la liste chainee
        // j'imprime toutes la liste dans un tableau de client

        tab[j].set_number(num);
        tab[j].set_shop_num(cl_num);
        tab[j].set_stat(etat);
        tab[j].set_refer(refe);
        tab[j].set_qte(qte);
        cout << "\n\nLe liste de vos commande contenu dans le fichier est : \n";
        for(int i=0;i<j;i++)
        {
            tab[i].show_commande();
        }

        cout << "nombre de commandes present dans le fichier : " << j <<" commande(s) \n";
            //j'insert le numero du client j dans la liste chainee de numero
    }

	flux_commande.close();

	ofstream flux_commande_sortie("C:/MesFichiersC++/Supermaket/Commandes/Fichier_Commande.txt", ios::app);
	if (taille == 0)
    {
        cout << "Le fichier etait vide\n\n";
        flux_commande_sortie << commande.get_number() <<"\t" << commande.get_shop_num()<<"\t"<<commande.get_stat()<<"\t"<<commande.get_refer()<<"\t" << commande.get_qte();
    }
    else
    {
        if (list_find_cmd(liste_num_commande,commande.get_number()))				// je verifie que le numero a entre ne se trouve pas dans la liste chainee
        {
            cout << "Impossible d'inserer cette commande sous ce numero, car il a deja ete enregistre a une autre commande \n";
        }
        else
        {
            flux_commande_sortie <<"\n" << commande.get_number()<<"\t"<< commande.get_shop_num() << "\t"<< commande.get_stat() << "\t" << commande.get_refer() <<"\t"<< commande.get_qte();
        }
    }
    flux_commande_sortie.close();
}


void insertion_fichier_commande(Commande *cmd, int n)
{
    ofstream fichier_commande("C:/MesFichiersC++/Supermaket/Commandes/Fichier_Commande.txt");
    for(int i=0;i<n;i++)
    {
        Enregistrer_commande(cmd[i]);
    }
}

/* Fonction qui permet de modifier une information dans le fichier commande */

void modifier_commande(int ancien, int nouveau)
{
    Commande *liste_commande = copy_commande_file();      // liste des commandes du fichier
    int n = nombre_ligne_fichier_commande();
    int indice = recherche_liste_commande_numero(ancien);
    if (indice != -1)
    {
        liste_commande[indice].set_number(nouveau);
        insertion_fichier_commande(liste_commande, n);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}


/*----Fonction de suppression dans le fichier client---------*/


void supprime_commande(int num)
{
    Commande *liste_commande = copy_commande_file();
    int indice = recherche_liste_commande_numero(num);
    int n = nombre_ligne_fichier_commande();
    if(indice != -1)
    {
        for(int i=indice; i<n-1;i++)
        {
            liste_commande[i]=liste_commande[i+1];
        }
        insertion_fichier_commande(liste_commande, n-1);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}

void entete3()
{
    cout << "\n\n\n\n";
    cout <<"                        ********************************************************** \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *              SUPER MARCHE EMERGENCE +++                * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        ********************************************************** \n\n\n\n";
}

void recherche_commande()
{
    int choix;
    system("CLS");
    entete3();
    cout << "                       --------------------------------------- \n";
    cout << "                              RECHERCHE D'UNE COMMANDE   \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Voulez vous chercher la commande en fonction du numero de la commande, numero du client, l'etat,la reference ou la quantite ?\n " ;
    cout << "____________________________________________________________________________________________________\n\n";
    cout << "       1- Numero de la commande \n";
    cout << "       2- Numero du client \n";
    cout << "       3- L'etat de la commande \n";
    cout << "       4- Reference de l'article concernee par la commande \n";
    cout << "       5- Quantite de la commande \n";
    cout << "____________________________________________________________________________________________________\n\n";
    cout << "                    Votre choix : " ; cin >> choix;

    if (choix ==1)
    {
        string val;
        system("CLS");
        entete3();
        cout << "                       ----------------------------------------------------------------\n";
        cout << "                         RECHERCHE D'UNE COMMANDE EN FONCTION LA REFERENCE DU PRODUIT   \n";
        cout << "                       ----------------------------------------------------------------  \n\n";
        cout << " Entrez la reference de l'article que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_commande_reference(val);
        system("PAUSE");
        recherche_commande();
    }

    if (choix == 2)
    {
        int val;
        system("CLS");
        entete3();
        cout << "                       ------------------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UNE COMMANDE EN FONCTION DU NUMERO DE COMMANDE  \n";
        cout << "                       ------------------------------------------------------------------  \n\n";
        cout << " Entrez le numero de la commande que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_commande_numero(val);
        system("PAUSE");
        recherche_commande();
    }
    if(choix==3)
    {
        int val;
        system("CLS");
        entete3();
        cout << "                       -----------------------------------------------------------\n";
        cout << "                          RECHERCHE D'UNE COMMANDE EN FONCTION DU NUMERO CLIENT  \n";
        cout << "                       -----------------------------------------------------------  \n\n";
        cout << " Entrez le numero du client concerne par cette commande que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_commande_num_client(val);
    }
    if(choix==4)
    {
        int val;
        system("CLS");
        entete3();
        cout << "                       ----------------------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UNE COMMANDE FONCTION DE LA QUANTITE COMMANDE       \n";
        cout << "                       ----------------------------------------------------------------------  \n\n";
        cout << " Entrez la quantite de commande que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_commande_quantite(val);
        system("PAUSE");
        recherche_commande();
    }
    if(choix==5)
    {
        string val;
        system("CLS");
        entete3();
        cout << "                       -----------------------------------------------------------------\n";
        cout << "                               RECHERCHE D'UNE COMMANDE EN FONCTION DE SON ETAT       \n";
        cout << "                       -----------------------------------------------------------------\n\n";
        cout << " Entrez la quantite seuil de l'article que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_commande_etat(val);
        system("PAUSE");
        recherche_commande();

    }
      else
    {
        system("CLS");
        entete3();
        cout << "\n\n\n\n\n                  CHOIX INDISPONIBLE......\n\n\n\n";
        system("PAUSE");
        recherche_commande();
    }
}

void choix_commande()
{
    system("CLS");
    entete3();
    cout << "                          ---------------------------------------------------------------\n";
    cout << "                                BIENVENUE DANS LE SYSTEME DE GESTION DES COMMANDES \n";
    cout << "                          --------------------------------------------------------------- \n\n\n";
    cout << " Choisissez une action a effectuer : \n";
    cout <<"_________________________________________________________________ \n\n\n";
    cout <<"1- Enregistrer une commande\n";
    cout <<"2- Modifier une commande \n";
    cout <<"3- Supprimer une commande \n";
    cout <<"4- Lister les commandes d'un lient en cours \n\n";
    cout <<"_________________________________________________________________ \n\n\n";

}

#endif
