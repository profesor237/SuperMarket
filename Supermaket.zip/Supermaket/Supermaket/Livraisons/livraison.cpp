#include <iostream>
#include "livraison.h"
#include <string>

Livraison::Livraison()
{
	numero_commande = 0;
	quantite =0;
	numero_client = 0;
	refer_article = "";
}
Livraison::Livraison(int num_cmd, int q, int num_client, std::string ref)
{
	numero_commande = num_cmd;
	quantite = q;
	numero_client = num_client;
	refer_article = ref;
}
void Livraison::set_numero_commande(int num_cmd)
{
	numero_commande = num_cmd;
}
int Livraison::get_numero_commande()
{
	return numero_commande;
}
void Livraison::set_quantite(int q)
{
	quantite = q;
}
int Livraison::get_quantite()
{
	return quantite;
}
void Livraison::set_numero_client(int num_client)
{
	numero_client = num_client;
}
int Livraison::get_numero_client()
{
	return numero_client;
}
void Livraison::set_refer_article(std::string ref)
{
	refer_article = ref;
}
string Livraison::get_refer_article()
{
	return refer_article;
}
void Livraison::show_livraison()
{
	std::cout << "La livraison est : \n Numero de la commande : "<< numero_commande << "\n L'article a live est : " << refer_article << " \n La quantite a livre est : " << quantite << "\n le numero du client est : " << numero_client <<"\n";
}
