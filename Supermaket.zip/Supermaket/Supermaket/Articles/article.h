#if !defined(__ARTICLE__)
#define __ARTICLE__

#include <list>
#include "../Livraisons/livraison.h"
#include "../Clients/client.h"
#include <iostream>
#include <string>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;

class Article
{
private:
	int refer_art;
	string libelle;
	int prix_unit;
	int qte_stock;
	int seuil_cri;
public:
	Article();
	Article(int, string, int, int, int);
	void set_refer(int);
	int get_refer();
	void set_libelle(string);
	string get_libelle();
	void set_prix_unit(int);
	int get_prix_unit();
	void set_qte_stock(int);
	int get_qte_stock();
	void set_seuil_cri(int);
	int get_seuil_cri();
	void show_article();

};

Article::Article()
{
	refer_art = 0;
	libelle = "";
	prix_unit = 0;
	qte_stock = 0;
	seuil_cri = 0;
}
Article::Article(int r, string l, int p, int q, int s)
{
	refer_art = r;
	libelle = l;
	prix_unit = p;
	qte_stock = q;
	seuil_cri = s;
}
void Article::set_refer(int r)
{
	refer_art = r;
}
int Article::get_refer()
{
	return refer_art;
}
void Article::set_libelle(string l)
{
	libelle = l;
}
string Article::get_libelle()
{
	return libelle;
}
void Article::set_prix_unit(int p)
{
	prix_unit = p;
}
int Article::get_prix_unit()
{
	return prix_unit;
}
void Article::set_qte_stock(int q)
{
	qte_stock = q;
}
int Article::get_qte_stock()
{
	return qte_stock;
}
void Article::set_seuil_cri(int s)
{
	seuil_cri = s;
}
int Article::get_seuil_cri()
{
	return seuil_cri;
}
void Article::show_article()
{
	cout << "L'article definie est : \n Reference : " << refer_art << "\n Libelle : " << libelle << "\n Prix unitaire" << prix_unit << "\n La quatite en stock est : " << qte_stock  << "\n Le seuil critique est : " << seuil_cri << "\n";
}

void menu1();
void choix_article();
void choix_article1();
void choix_article2();

int nombre_ligne_fichier_article()
{
	int n=0;
	ifstream flux_article("C:/MesFichiersC++/Supermaket/Articles/Fichier_Article.txt", ios::in);
	string ligne;
    while(getline(flux_article, ligne))
    {
        n++;
        cout << "ligne numero :"<<n;
    }
    flux_article.close();
	return n;
}

//--------creation d'une liste chainees

// recherche d'une valeur dans une lise chainee

bool list_find_ref(list<int> l, int val)
{
	bool trouver = 0;
	for(list<int>::iterator it = l.begin(); it!=l.end();++it)
	{
		if(*it == val)
			trouver = 1;
	}
	return trouver;
}
// Fonction de copie du contenue d'un fichier dans un tableau
Article *copy_article_file()        // represente la taille du tableau
{
    Article *tab = new Article[100];
	ifstream flux_article("C:/MesFichiersC++/Supermaket/Articles/Fichier_Article.txt" , ios::in);
	int taille = nombre_ligne_fichier_article();

    for(int j=0;j<=taille;j++)
    {
        string libelle;  int refer_art, prix_unit, qte_stock, seuil_cri;
        flux_article >> refer_art >> libelle >> prix_unit >> qte_stock >> seuil_cri;

    // j'imprime toutes la liste dans un tableau de client

        tab[j].set_refer(refer_art);
        tab[j].set_libelle(libelle);
        tab[j].set_prix_unit(prix_unit);
        tab[j].set_qte_stock(qte_stock);
        tab[j].set_seuil_cri(seuil_cri);
	}
	flux_article.close();
	return tab;
}

//----------insertion des valeurs d'une liste dans le fichier

int recherche_liste_article_reference(int val)
{
    Article *liste_article = copy_article_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_article();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_article[i].get_refer()==val)
            return i;
    }
    return -1;
}

int recherche_liste_article_libelle(string libelle)             //recherche en fonction du nom du client
{
    Article *liste_article = copy_article_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_article();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_article[i].get_libelle()==libelle)
            return i;
    }
    return -1;
}

int recherche_liste_article_prix_unit(int prix_unit)             // recherche en fonction du prenom du client
{
    Article *liste_article = copy_article_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_article();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_article[i].get_prix_unit()==prix_unit)
            return i;
    }
    return -1;
}

int recherche_liste_article_qte_stock(int qte_stock)
{
    Article *liste_article = copy_article_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_article();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_article[i].get_qte_stock()==qte_stock)
            return i;
    }
    return -1;
}

int recherche_liste_article_seuil_cri(int seuil_cri)
{
    Article *liste_article = copy_article_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_article();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_article[i].get_seuil_cri()==seuil_cri)
            return i;
    }
    return -1;
}



void Enregistrer_article(Article article)
{
	int taille;
	list<int> liste_ref_article;				// stocke less dentifiant de chaque client (numero)
	ifstream flux_article("C:/MesFichiersC++/Supermaket/Articles/Fichier_Article.txt" , ios::in);

	taille = nombre_ligne_fichier_article();
    Article tab[taille+1];
    for(int j=0;j<=taille;j++)
    {
        string libelle; int refer_art, prix_unit, qte_stock, seuil_cri;
        flux_article >> refer_art >> libelle >> prix_unit >> qte_stock >> seuil_cri;

        liste_ref_article.push_back(refer_art);        // je met le numero du client dans la liste chainee
        // j'imprime toutes la liste dans un tableau de client

        tab[j].set_refer(refer_art);
        tab[j].set_libelle(libelle);
        tab[j].set_prix_unit(prix_unit);
        tab[j].set_qte_stock(qte_stock);
        tab[j].set_seuil_cri(seuil_cri);
        cout << "\n\nLe liste de vos client contenu dans le fichier est : \n";
        for(int i=0;i<j;i++)
        {
            tab[i].show_article();
        }

        cout << "nombre de article present dans le fichier : " << j <<" article(s) \n";
            //j'insert le numero du client j dans la liste chainee de numero
    }

	flux_article.close();

	ofstream flux_article_sortie("C:/MesFichiersC++/Supermaket/Articles/Fichier_Article.txt", ios::app);
	if (taille == 0)
    {
        cout << "Le fichier etait vide\n\n";
        flux_article_sortie << article.get_refer() <<"\t" << article.get_libelle()<<"\t"<<article.get_prix_unit()<<"\t"<<article.get_qte_stock()<<"\t" << article.get_seuil_cri()<<"\n\n";
    }
    else
    {
        if (list_find_ref(liste_ref_article,article.get_refer()))				// je verifie que le numero a entre ne se trouve pas dans la liste chainee
        {
            cout << "Impossible d'inserer cet article sous ce numero, car il a deja ete enregistre a un autre  \n";
        }
        else
        {
        	flux_article_sortie << article.get_refer() <<"\t" << article.get_libelle()<<"\t"<<article.get_prix_unit()<<"\t"<<article.get_qte_stock()<<"\t" << article.get_seuil_cri()<<"\n\n";
        }
    }
    flux_article_sortie.close();
}

void insertion_fichier_article(Article *art, int n)
{
    ofstream fichier_article("C:/MesFichiersC++/Supermaket/Articles/Fichier_Article.txt");
    for(int i=0;i<n;i++)
    {
        Enregistrer_article(art[i]);
    }
}

/* Fonction qui permet de modifier une information dans le fichier client */

void modifier_article(int ancien, int nouveau, string lib, int p, int q, int s)
{
    Article *liste_article = copy_article_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_article();
    int indice = recherche_liste_article_reference(ancien);
    if (indice != -1)
    {
        liste_article[indice].set_refer(nouveau);
        insertion_fichier_article(liste_article, n);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}

/*----Fonction de suppression dans le fichier client---------*/

void supprime_article(int refer_art)
{
    Article *liste_article = copy_article_file();
    int num;
    int indice = recherche_liste_article_reference(num);
    int n = nombre_ligne_fichier_article();
    if(indice != -1)
    {
        for(int i=indice; i<n-1;i++)
        {
            liste_article[i]=liste_article[i+1];
        }
        insertion_fichier_article(liste_article, n-1);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}
void entete1()
{
    cout << "\n\n\n\n";
    cout <<"                        ********************************************************** \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *              SUPER MARCHE EMERGENCE +++                * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        ********************************************************** \n\n\n\n";
}

void recherche_article()
{
    int choix;
    system("CLS");
    entete1();
//    entete();
    cout << "                       --------------------------------------- \n";
    cout << "                              RECHERCHE D'UN ARTICLE   \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Voulez vous rechercher l'article  en fonction de quoi?\n " ;
    cout << "___________________________________________________________________\n\n";
    cout << "       1-Reference de l'article\n";
    cout << "       2-Libelle de l'article\n";
    cout << "       3-Prix unitaire de l'article\n";
    cout << "       4-Quantite en stock de l'article\n";
    cout << "       5-Seuil critique de l'article\n\n";
    cout << "___________________________________________________________________\n\n";
    cout << "                 Votre choix : ";cin >> choix;

    if (choix == 1)
    {
        int val;
        system("CLS");
        entete1();
        cout << "                       --------------------------------------------------------\n";
        cout << "                          RECHERCHE D'UN ARTICLE EN FONCTION DE SA REFERENCE   \n";
        cout << "                       --------------------------------------------------------  \n\n";
        cout << " Entrez la reference de l'article que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_article_reference(val);
        system("PAUSE");
        recherche_article();
    }

    if (choix == 2)
    {
        string val;
        system("CLS");
        entete1();
        cout << "                       ------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN ARTICLE EN FONCTION DU LIBELLE  \n";
        cout << "                       ------------------------------------------------------  \n\n";
        cout << " Entrez le nom du client que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_article_libelle(val);
#include <iostream>
#include <string>
#include <stdlib.h>em("PAUSE");
        recherche_article();
    }
    if(choix==3)
    {
        int val;
        system("CLS");
        entete1();
        cout << "                       -----------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN ARTICLE EN FONCTION DU PRIX UNITAIRE  \n";
        cout << "                       -----------------------------------------------------------  \n\n";
        cout << " Entrez le prix unitaire de l'article que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_article_prix_unit(val);
        system("PAUSE");
        recherche_article();
    }
    if(choix==4)
    {
        int val;
        system("CLS");
        entete1();
        cout << "                       ----------------------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN ARTICLE EN FONCTION DE LA QUANTITE EN STOCK       \n";
        cout << "                       ----------------------------------------------------------------------  \n\n";
        cout << " Entrez la quantite de l'article que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_article_qte_stock(val);
        system("PAUSE");
        recherche_article();
    }
    if(choix==5)
    {
        int val;
        system("CLS");
        entete1();
        cout << "                       -----------------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN ARTICLE EN FONCTION DE SON SEUIL CRITIQUE        \n";
        cout << "                       -----------------------------------------------------------------\n\n";
        cout << " Entrez la quantite seuil de l'article que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_article_seuil_cri(val);
        system("PAUSE");
        recherche_article();
    }
    else

    {
        system("CLS");
        entete1();
        cout << "\n\n\n\n\n                  CHOIX INDISPONIBLE......\n\n\n\n";
        system("PAUSE");
        recherche_article();
    }
}

void menu1()
{
    int n;
    system("CLS");
    entete1();
    cout << " Choisissez une action a effectuer : \n";
    cout <<"_________________________________________________________________ \n\n";
    cout <<"1- Gestion des articles \n";
    cout <<"2- Gestion des clients   \n";
    cout <<"3- Gestion des commandes \n";
    cout <<"4- Gestion des livraisons \n";
    cout <<"5- Calculer le capital du supermarche \n\n";
    cout <<"_________________________________________________________________ \n\n";
    cout <<"    Votre choix : " <<endl; cin >> n;

    if(n == 1)
        choix_article();
    /*else if(n==2)
        choix_client();*/
    else if(n==3)
       choix_commande();
    else if(n==4)
        choix_livraison();
    /*else if(n==5)
        choix_capital();*/
    else
    {
        system("CLS");
        entete1();
       cout << " \n\n\n\n                   CHOIX INDISPONIBLE.....\n\n\n\n";
       system("PAUSE");
       menu1();
    }


}

void choix_article()
{
    int n;
    system("CLS");
    entete1();
    cout << "                         ------------------------------------------------------------------\n";
    cout << "                                BIENVENUE DANS LE SYSTEME DE GESTION DES ARTICLES           \n";
    cout << "                         ------------------------------------------------------------------ \n\n\n";
    cout << " Choisissez une action a effectuer : \n";
    cout <<"_________________________________________________________________ \n\n\n";
    cout <<"1- Enregistrer un article\n";
    cout <<"2- Rechercher un article \n";
    cout <<"3- Modifier un article \n";
    cout <<"4- Supprimer un article \n";
    cout <<"5- Lister les articles achetes par un client precis \n";
    cout <<"6- Lister les articles et leur prix unitaire \n";
    cout <<"7- Faire les statistiques sur les ventes d'un article\n";
    cout <<"8- Afficher les articles a ravitailler \n\n";
    cout <<"9- RETOUR \n\n";
    cout <<"_________________________________________________________________ \n\n\n";
    cout << "         Votre choix :  "; cin >> n;
    if (n==1)
        choix_article1();
    /*else if(n==2)
        choix_article2();
    else if(n==3)
    choix_article3();
    else if(n==4)
        choix_article4();
    else if(n==5)
        choix_article5();
    else if(n==6)
        choix_article6();
    else if(n==7)
        choix_article7();
    else if(n==8)
        choix_article8();*/
    else if ( n==9)
    {
        system("PAUSE");
        menu1();
    }
    else
    {
        cout << " \n\n\n\n     CHOIX INDISPONIBLE.....\n\n";
       system("PAUSE");
       choix_article();
    }



}


void choix_article1()
{
    int n;
    system("CLS");
    entete1();
    cout << "                       --------------------------------------- \n";
    cout << "                             ENREGISTREMENT DES ARTICLES       \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Combien d'articles voulez-vous enregitrer ?  "; cin >> n;

    for(int i=0;i<n;i++)
    {
        int reff, pu, qte, seuil; string nom;
        Article tab[100];
        cout << "   -Enregistrement de l'article numero  " << i+1 << endl;
        cout << "   -reference de l'article client :  "; cin >> reff;
        cout << "   -Libelle: "; cin >>nom;
        cout << "   -Prix unitaire: "; cin >> pu;
        cout << "   -Quantite en stock : "; cin >>qte;
        cout << "   -Seuil critique :  " ; cin >> seuil; cout << "\n\n";
        tab[i].set_refer(reff); tab[i].set_libelle(nom); tab[i].set_prix_unit(pu); tab[i].set_qte_stock(qte); tab[i].set_seuil_cri(seuil);
        Enregistrer_article(tab[i]);

    }
    system("PAUSE");
    choix_article();

}

void choix_article2()
{
   recherche_article();
   string c;
    if (c=="O" || c=="o"|| c=="OUI"||c=="oui")
    {
        system("CLS");
        choix_article();
    }
    else
    {
        system("CLS");
        choix_article2();
    }
}

void choix_article3()
{
    int n, nnu, npu, nqte, ns;
    string nlib;
    system("CLS");
    entete1();
    cout << "                       --------------------------------------- \n";
    cout << "                             MODIFICATION D'UN ARTICLE       \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Entrer le numero de l'article que vous souhaitez modifier ?  "; cin >> n;
    cout << " Entrez les nouvelles informations sur le client : \n";
    cout << "    -Reference : "; cin >> nnu;
    cout <<"     -Libelle : "; cin >> nlib;
    cout << "    -Prix unitaire "; cin >> npu;
    cout << "    -Quantite en stock : "; cin >> nqte;
    cout << "    -Seuil critique : "; cin >> ns;
    modifier_article(n, nnu, nlib, npu, nqte, ns);
    system("PAUSE");
    system("CLS");
    choix_article();

}

void choix_article4()
{
    int nu;
    system("CLS");
    entete1();
    cout << "                       --------------------------------------- \n";
    cout << "                               SUPPRESSION D'UN ARTICLE        \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Entrez la reference de l'article que vous souhaitez supprimer :  "; cin >> nu;
    supprime_article(nu);
    system ("PAUSE");
    system("CLS");
    choix_article();
}

void choix_article5()
{
    int nu;
    system("CLS");
    entete1();
    cout << "                     -------------------------------------------- \n";
    cout << "                      LISTE DES ARTICLES ACHETES PAR UN CLIENT       \n";
    cout << "                     --------------------------------------------  \n\n";
    cout << "Entrez la reference de l'article dont vous souhaitez connaitre les clients :  "; cin >> nu;
}


#endif
