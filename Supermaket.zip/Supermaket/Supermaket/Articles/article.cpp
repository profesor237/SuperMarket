#include <iostream>
#include "article.h"
#include <string>

Article::Article()
{
	refer_art = "";
	libelle = "";
	prix_unit = 0;
	qte_stock = 0;
	seuil_cri = 0;
}
Article::Article(std::string r, std::string l, int p, int q, int s)
{
	refer_art = r;
	libelle = l;
	prix_unit = p;
	qte_stock = q;
	seuil_cri = s;
}
void Article::set_refer(std::string r)
{
	refer_art = r;
}
string Article::get_refer()
{
	return refer_art;
}
void Article::set_libelle(std::string l)
{
	libelle = l;
}
string Article::get_libelle()
{
	return libelle;
}
void Article::set_prix_unit(int p)
{
	prix_unit = p;
}
int Article::get_prix_unit()
{
	return prix_unit;
}
void Article::set_qte_stock(int q)
{
	qte_stock = q;
}
int Article::get_qte_stock()
{
	return qte_stock;
}
void Article::set_seuil_cri(int s)
{
	seuil_cri = s;
}
int Article::get_seuil_cri()
{
	return seuil_cri;
}
void Article::show_article()
{
	std::cout << "L'article definie est : \n Reference : " << refer_art << "\n Libelle : " << libelle << "\n Prix unitaire" << prix_unit << "\n La quatite en stock est : " << qte_stock  << "\n Le seuil critique est : " << seuil_cri << "\n";
}
